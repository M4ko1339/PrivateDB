-- English localization

MCP_ADDON_LOADED = "Loaded";
MCP_ADDON_WILL_NOT_LOAD = "Will not load";
MCP_ADDON_REFUSE_TO_LOAD = "Disabled in MCP";
MCP_LOADED_ON_DEMAND = "Loaded on demand.";

MCP_RELOAD = "Reload your user interface?";
MCP_DELETE_PROFILE_DIALOG = "Delete profile: ";
MCP_PROFILE_NAME_SAVE = "Profile name";

MCP_PROFILE_SAVED = "Profile saved: ";
MCP_PROFILE_DELETED = "Profile deleted: ";
MCP_NO_PROFILE_DELETED = "No profile deleted.";

MCP_LOAD = "Load";
MCP_ADDONS = "AddOns";
MCP_RELOADUI = "ReloadUI";
MCP_SAVE_PROFILE = "Save Profile";
MCP_DELETE_PROFILE = "Delete Profile";
MCP_ENABLE_ALL = "Enable All";
MCP_DISABLE_ALL = "Disable All";

MCP_NO_NOTES = "No information available.";
