﻿

if (GetLocale() == "frFR") then

	XPERL_LOAD		= "Lancer"

	XPERL_RAID_TOOLTIP_NOCTRA	= "Pas de CTRA trouv\195\169"

	XPERL_REAGENTS			= {PRIEST = "Bougie sacr\195\169e", MAGE = "Poudre des arcanes", DRUID = "Ronceterre sauvage",
					SHAMAN = "Ankh", WARLOCK = "Fragment d'\195\162me", PALADIN = "Symbole de divinit\195\169",
					ROGUE = "Flash Powder"}
end
