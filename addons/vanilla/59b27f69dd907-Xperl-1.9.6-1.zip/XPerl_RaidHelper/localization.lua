﻿

XPERL_MSG_PREFIX	= "|c00C05050X-Perl|r "
XPERL_COMMS_PREFIX	= "X-Perl"

XPERL_TOOLTIP_ASSISTING	= "Players Assisting:"
XPERL_TOOLTIP_HEALERS	= "Healers Targetting Me:"
XPERL_TOOLTIP_ALLONME	= "All Targetting Me:"
XPERL_TOOLTIP_ENEMYONME	= "Enemy Targetting Me:"
XPERL_TOOLTIP_HELP	= "Click to open real time view"
XPERL_TOOLTIP_PET	= "%s's pet"

XPERL_LOC_DEAD		= "Dead"

BINDING_HEADER_XPERL = "X-Perl Key Bindings"
BINDING_NAME_TARGETFIRSTOTHER = "Target First Non-Tanked Target"
BINDING_NAME_SMARTASSIST = "Smart Assist"

XPERL_BUTTON_TOGGLE_STATS_DESC	= "Toggle target statistics"
XPERL_BUTTON_EXPAND_DESC	= "Expand other targets list"
XPERL_BUTTON_EXPAND_LOCK	= "Always Expand non tanked target list, otherwise only first row of targets will be displayed unless you mouse over the area."
XPERL_BUTTON_TOGGLE_LABELS	= "Toggle Target Labels"
XPERL_BUTTON_TOGGLE_TARGETS	= "Toggle Other targets showing their target"
XPERL_BUTTON_TOGGLE_MTTARGETS	= "Toggle MT targets showing their target"
XPERL_BUTTON_TOGGLE_SHOWMT	= "Toggle showing of the Main Tank"
XPERL_BUTTON_HELPER_PIN		= "Pin Window"

XPERL_STATS_NO_TARGET		= "%s with no target. Slackers!"
XPERL_STATS_NOT_ASSIST_MT1	= "%s dps not assisting %s"
XPERL_STATS_NOT_ASSIST_ANY	= "%s dps not assisting any MT"
XPERL_STATS_HEALERS_MT1		= "%s healers on %s"
XPERL_STATS_HEALERS_ANY		= "%s healers on other MTs"
XPERL_STATS_HEALERS_NON_MT	= "%s healers not on MTs"

XPERL_XS_TARGET			= "%s's target"
XPERL_NO_TARGET			= "no target"

XPERL_TITLE_MT_LONG		= "MT Targets"
XPERL_TITLE_MT_SHORT		= "MT"
XPERL_TITLE_WARRIOR_LONG	= "Warrior Targets"
XPERL_TITLE_WARRIOR_SHORT	= "Tanks"

XPERL_TITLE_OTHERS		= "Other Targets"
XPERL_TARGET_STATISTICS		= "Target Statistics"

XPERL_KEYHELP1			= "You can define a key"
XPERL_KEYHELP2			= " to target first un-tanked mob"

XPERL_FOOTER_MORE		= "%d more..."
XPERL_TO_TARGET			= "%s to target"

XPERL_HELPER_NEEDPROMOTE	= "You must be promoted to set the Main Assist"
XPERL_HELPER_MASET		= "Main Assist set to %s"
XPERL_HELPER_MACLEAR		= "Main Assist |c00FF0000cleared!"
XPERL_HELPER_MAREMOVED		= "Main Assist %s not found in tank list - removed!"
XPERL_HELPER_MAREMOTESET	= "%s has assigned the Main Assist to be %s"

XPERL_HELPER_FINDFOUND		= "Using FIND found suitable target. ('|c00007F00/xp find|r' to clear)."
XPERL_HELPER_FINDCLEARED	= "Find |c00FF0000cleared!|r"
XPERL_HELPER_FINDSET		= "Find set to %s. ('|c00007F00/xp find|r' to clear)."

XPERL_AGGRO_PLAYER		= "- AGGRO -"
XPERL_AGGRO_PET			= "- PET AGGRO -"

if ( GetLocale() == "frFR" ) then
	XPERL_LOC_DEAD = "Mort"

elseif ( GetLocale() == "koKR" ) then
	XPERL_LOC_DEAD = "죽음"
end
