local L = AceLibrary("AceLocale-2.2"):new("AuctionLink")
L:RegisterTranslations("enUS", function()
	return {
		["autosearch"] = true,
		["Automatically search after clicking an item"] = true,
		["/alink"] = true,
		["/auctionlink"] = true
	}
end)