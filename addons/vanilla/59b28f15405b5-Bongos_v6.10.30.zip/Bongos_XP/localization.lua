--[[
	Bongos XP Localization file
--]]

BONGOS_XP_HORIZONTAL_TEXTURE = 'Interface\\Addons\\Bongos_XP\\statusbar6'
BONGOS_XP_VERTICAL_TEXTURE = 'Interface\\Addons\\Bongos_XP\\statusbar6v'

BONGOS_XP_VERTICAL = 'Vertical'
BONGOS_XP_HEIGHT = 'Height'
BONGOS_XP_WIDTH = 'Width'