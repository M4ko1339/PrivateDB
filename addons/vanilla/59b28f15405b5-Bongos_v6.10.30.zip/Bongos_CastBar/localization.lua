--[[
	Bongos CastBar Localization file
--]]

BONGOS_CASTBAR_SHOW_TIME = "Show Time"