Big Wigs Common Auras

A Big Wigs plugin that reports common buffs and debuffs to your screen with
timer bars, messages and optionally raid warning.

Currently it supports the following buffs and debuffs:
 * Fear Ward with cooldown display
 * Shield Wall with duration
 * Last Stand with duration
 * Challenging Shout and Challenging Roar with duration display and a
   global function for targetting the last person that used it.
 * Mage Portals with duration and destination.

I've been thinking about adding soulstones, Last Stand and lots of other
things, but I haven't really come around to it yet or figured out if I really
want it or not.

You can access the options through BW's menu in Plugins -> Common Auras.

The most important thing to note about this plugin is that it requires people
in your raid to have it. It will not report Challenging Shout unless both the
warrior and you have the mod. Other people will not see raid warnings unless a
raid leader also has the mod.

