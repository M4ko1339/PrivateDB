local L = AceLibrary("AceLocale-2.2"):new("BT2Circled")

L:RegisterTranslations("enUS", function() return {
	["Circled skin"] = true,
	["Config for Circled skin"] = true,
	["Colors"] = true,
	["Change ring colors."] = true,
	["Normal"] = true,
	["Normal ring color."] = true,
	["Hover"] = true,
	["Hover ring color."] = true,
	["Equipped"] = true,
	["Equipped ring color."] = true,
	["Toggle"] = true,
	["Toggle skin per bar."] = true,
	["bagbar"] = true,
	["Toggle skin on bagbar"] = true,
	["Skin"] = true,
	["Select button skin."] = true,
	["Toggle skin on %s"] = true,
} end)