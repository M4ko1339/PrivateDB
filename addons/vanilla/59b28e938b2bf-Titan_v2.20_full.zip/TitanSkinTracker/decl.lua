--
-- Credits to WalleniuM for his original code of Titan[ReagentBuff]
--

-- leather types
	XY_SKIN_LIGHT		= "Light Leather";
	XY_SKIN_MEDIUM		= "Medium Leather";
	XY_SKIN_HEAVY		= "Heavy Leather";
	XY_SKIN_THICK		= "Thick Leather";
	XY_SKIN_RUGGED		= "Rugged Leather";
-- dragonscales
	XY_DRAGONSCALE_BLACK	= "Black Dragonscale";
	XY_DRAGONSCALE_BLUE	= "Blue Dragonscale";
	XY_DRAGONSCALE_GREEN	= "Green Dragonscale";
-- black diamond
	XY_DIAMOND_BLACK	= "Black Diamond";


	
-- the rest :D
	TITAN_SKINTRACKER_BUTTON_LABEL     = "Skins: ";
	TITAN_SKINTRACKER_MENU_RESET       = "Reset Data";
	TMS_RANK_NAME                      = "rank";
	TITAN_SKINTRACKER_TOOLTIP_HEADER   = "";
	TITAN_SKINTRACKER_TOOLTIP_ERROR    = "No Data!";
	TITAN_SKINTRACKER_NA               = "N/A";
	TITAN_SKINTRACKER_YES              = "Yes";
	TITAN_SKINTRACKER_NO               = "No";
	
-- system settings
	TITAN_SKINTRACKER_LOADED           = "loaded";
	TITAN_SKINTRACKER_NAME_VERSION     = "version";
	TITAN_SKINTRACKER_SYS_UPDATE       = "Update complete";
	TITAN_SKINTRACKER_SYS_NOUPDATE     = "No Update needed";
	TITAN_SKINTRACKER_SYS_UPDATING     = "updating from version";
