SkinTracker v2.0 by Xytro (Shattered Hand, Vek'Nilash)
Based on the code of Titan[BuffReagent] coded by WalleniuM

This mod tracks the number of different skins in your inventory.
As soon as you have 10 or more, it shows up in green (So you know when you have enough to sell on the AH).

Credits :
WalleniuM - original Titan[ReagentBuff] on wich this mod is based
Vicky

Version History :

v2.1
----
	- Removed a line of code, causing to "flood" the chatbox when you
	  opened the tooltip.

v2.0
----
	- Added option for Black Diamonds
	- Variables should be saved correctly now
	- Updated for patch 1.10
	- Removed  color code for quantity, working on a fix :)

v 1.1.0
-------
	- Added option for dragonscales (black, green & blue)
	- Added option for displaying how many stacks you have
	  (show as : 4 [Stack: 2]... this means you have 2 stacks (1 stack = 10 leathers) and 4 leathers, so 24 in total in your inventory)
v 1.0.1
-------
	- Added support for items stored in your bank & inventory
	  (you still need to open your bank / mailbox once before it shows up)