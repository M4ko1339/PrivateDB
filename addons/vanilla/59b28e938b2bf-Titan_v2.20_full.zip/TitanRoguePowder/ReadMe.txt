Titan Panel [RoguePowder] 2.4 by Kosta (EU Bloodfeather realm)

DE translation: silver2k (Worldofwar.Net)
FR translation: Sparrows (Curse Gaming)

Worldofwar.Net: http://ui.worldofwar.net/ui.php?id=2431
Curse Gaming:   http://www.curse-gaming.com/mod.php?addid=3803

Displays the number of Flash Powder, Blinding Powder, Thistle Tea, Poisons and Bandages in inventory.
Titan Panel [RoguePowder] is plugin for Titan Panel, without Titan Panel this plugin don't work.

***** [ TO-DO ] *****

- add more config options
- add in-game info bar

***** [ KNOWN BUGS ] *****

If is enable counting healing and cure powders and is disabled counting only available powders,
in tooltip can't see all powders for max height of Titan tooltip.

***** [ CHANGELOG ] *****

2.4.5 (22.06.2006)
    - update TOC to 1.11

2.4.4 (05.05.2006)
    - fix HINT_BAGS_TEXT in FR translation

2.4.3 (03.05.2006)
    - FR localization
    - DE localization

2.4.1 (02.05.2006)
    - fix DE and FR names for heling and cure powders

2.4 (30.04.2006)
    - added healing and cure powders counting (default off)
    - added basic settings dialog
    - added left click for open settings
    - changed left click for open all bags to shift+left click
    - removed date identifier from version numbers

2.3 (26.04.2006)
    - added French translation (thanks Sparrows)

2.2 (23.04.2006)
    - added posions
    - added new option for show only available powders
    - added new option to turn off colored amount numbers
    - added localization for German clients (thanks silver2k)
    - added base english localization for French clients
    - removed "Titan" from Rogue Powder name in menu
    - removed misc functions
    - memory usage lowered to 36 kB

2.1 (15.04.2006)
    - code improvement and changes
    - variables changes
    - functions changes
    - added register and unregister events
    - base Titan function implemented
    - added base right click info menu frame
    - added info tooltip
    - left click on AddOn panel bar open bags
    - Titan Panel Rogue Powder added to "Information" section in Titan menu

2.0 (13.04.2006)
    - first continued version
    - update for 1.10
    - code clearing