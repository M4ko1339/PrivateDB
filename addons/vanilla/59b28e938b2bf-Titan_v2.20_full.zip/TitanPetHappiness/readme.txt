Titan Panel [Pet Happiness]
by FurryNeko
http://www.furryneko.com/

A good friend of mine noticed that there were no Titan
plugins to show the current state of your pets happiness.

Well, with no real previous LUA coding experience, and
90 minutes of my time, this is the result.

Simply extract into your AddOns folder and find it
under Titan Panels menus (Under Information).

Enjoy!

Revision History:
v1.0a - 9th Feb 06
Initial Public Release

v1.1 - 13th Feb 06
Added: Feeding pet status (Thanks for the idea Elsia!)
Fixed: Capitalization in tooltip

v1.11 - 13th Feb 06
Added: Toggle for showing feeding status