MONKEYSPEED_TITLE			= "MonkeySpeed";
MONKEYSPEED_VERSION			= "1.5";
MONKEYSPEED_TITLE_VERSION	= MONKEYSPEED_TITLE .. " v" .. MONKEYSPEED_VERSION;
MONKEYSPEED_DESCRIPTION		= "Displays your speed as a percentage of run speed.";
MONKEYSPEED_LOADED			= "|cffffff00" .. MONKEYSPEED_TITLE .. " v" .. MONKEYSPEED_VERSION .. " loaded";

MONKEYSPEED_CONFIRM_RESET	= "Okay to reset " .. MONKEYSPEED_TITLE .. " settings to default values?";

TITAN_SPEED_MENU_TEXT = "MonkeySpeed";
TITAN_SPEED_BUTTON_TEXT = "Speed: %s";