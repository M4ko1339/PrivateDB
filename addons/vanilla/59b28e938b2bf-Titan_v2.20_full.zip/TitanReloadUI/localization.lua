TITAN_RELOADUI_VERSION = "0.04";

TITAN_RELOADUI_MENU_TEXT = "ReloadUI"
TITAN_RELOADUI_BUTTON_LABEL = "ReloadUI"
TITAN_RELOADUI_BUTTON_TEXT = "%s";
TITAN_RELOADUI_TOOLTIP = "ReloadUI";

TITAN_RELOADUI_HINT_TEXT = "Hint: Left-click to reload the UI.";

TITAN_RELOADUI_ABOUT_TEXT = "About";
TITAN_RELOADUI_ABOUT_POPUP_TEXT = TitanUtils_GetGreenText("Titan Panel [ReloadUI]").."\n"..TitanUtils_GetNormalText("Version: ")..TitanUtils_GetHighlightText(TITAN_RELOADUI_VERSION).."\n"..TitanUtils_GetNormalText("Author: ")..TitanUtils_GetHighlightText("Corgi");