ClothTracker v2.0 by AxaliaN (Freyalise/Evanescent @ Chromaggus EU)
Based on the code of Titan[SkinTracker] coded by Xytro
Based on the code of Titan[BuffReagent] coded by WalleniuM

This mod tracks the number of different cloth in your inventory.
As soon as you have 10 or more, it shows up in green (So you know when you have enough to sell on the AH or whatnot).

To switch between bolt and cloth tracking, click on the icon in Titan.

-------------------------------------------------------------
-- CHANGELOG
-------------------------------------------------------------

2.0.1 06/11/06

Fixed a bug which occured when you got 10 or more cloth/bolts.

2.0 06/11/06

Added support for bolts of cloth. Updated for latest version.

1.0 Initial Release

Credits :
Xytro - He wrote the Titan[SkinTracker], the big brother of this mod ;) You rule dude!
WalleniuM - original Titan[ReagentBuff] on wich this mod is based