BattleGround Warning version 1.1.11200

Raid channel usage removed. Battleground channel used for human readable and the new (patch 1.12)
AddOn channel is used for AddOn interaction. No additional functionality added.
Not compatible with v1.0.11000.

------------------------------------------
BattleGround Warning version 1.0.11000

BG Warning is a sub zone warning tool for battleground PvP.
It requires Titan Panel AddOn to be installed.
It's best suited for Arathi Basin which contains small sub zones that gives more correct location information.

The interface contains three buttons and one warning information field able to contain up to 5 incomming messages.
The three buttons:
'I' - incomming, notifies 'Inc to <sub zone>' if pressed to raid chat.
It put's the sub zone on top in the warning information field.
Warnings in the information field are timed out after 60sec.
This is not a 'spam' button. Please use it with care.

'H' - help, notifies 'Need help at <sub zone>' if pressed to raid chat.
This is the 'spaming' button, but please still use it with care.

'S' - safe, notifies '<sub zone> safe' if pressed to raid chat.
Matching sub zone in warning information field will be removed, if not already timed out.

The warning informtion field will be updated if other users of this AddOn clicks the 'I' or 'S' buttons.
If not in any sub zone, will the interface be disabled.

Help can be shown in chat window by writing, '/bgw'.

Programming: Dash on Kul-Tiras (EU)
Idea: Valtar on Kul-Tiras (EU)
