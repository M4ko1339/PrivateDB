Titan ManaGem - version .92
Written By Patrick Wall

Description:
Titan ManaGem is a utility for Titan Panel (which you can see details of here: http://ui.worldofwar.net/ui.php?id=1442).  It allows the summoning and using of managems from one button.

Installation:
Copy "TitanManaGem" directory into your <World of Warcraft directory>/Interface/Addons.

Usage:
You use ManaGem by clicking on it to use gems from the biggest to the smallest, and shift clicking it to summon them in the same order.

Slash Commands:
/managem help			- Displays help
/managem summon			- Summons Managem
/managem use			- Uses Managem

Changelog:
v .92 - Added German support, thanks Spacer for translating it.  Also added basic French, Chinese, and Korean Support.

v .91 - Fixed a bug where some people didn't have HasSpell(), thanks watermaker for catching this 

v .9 - Minor update, improved "/managem" command output 

v .7 - Initial Public release