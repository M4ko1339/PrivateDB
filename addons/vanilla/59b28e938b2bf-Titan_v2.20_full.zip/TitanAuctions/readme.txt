TitanAuctions
by Smuggles

This addon uses TitanPanel and displays your auctions.

Features :

-remembers all auctions / bids from all auction houses
-keeps track if you get updates (sold,expired,outbid,etc)
-shows you estimated remaining time if wanted
-plays a sound to notify you of updates if wanted
-can be very small in titan bar (only icon)

IMPORTANT:
For TitanAuctions to get / update all the auction data you have to select the auctions / bids tab when visiting the AH at least once.

if automatic update is not checked, you also have to left click the icon once after selecting the tabs.

you can verify that all has been scanned by seeing how many auctions / bids you have near the icon

When you get an update you should look at the tooltip to see what happend and then the update will be removed from button.

If TitanAuctions cant fit all auctions/bids on 1 tooltip it will seperate bids and auctions
-auctions shown by mouseover WITHOUT Shift held
-bids shown by mouseover WITH Shift held

----------------------------------------------
SOUND NOTE : In order for this addon to play your defined sound, just find a usable wav you wanna play rename it to "titanauctions.wav" and 
put it in the /World of Warcraft/Data/ folder. the sound folder includes just a sample file you can use.

SOUND HINWEIS : damit PRB den eingen Sound beim blinken abspielt muss man eine WAV datei nehmen sie in "titanauctions.wav" umbenennen und
sie in das Verzeichnis /World of Warcraft/Data/ schieben. im sound verzeichnis ist nur eine beispiel datei.
----------------------------------------------

To Come :

-options to show even more data about all your auctions, its already saved, just has to be displayed

Version History
v1.3
-some minor improvements on updating
-implemented functionality if not all bids/auctions fit in tooltip use Shift+mouseover to show bids
-while in auction house, button will always show how many bids / auctions are aquired, even in small button mode, so you can verify
-calculates total value of your auctions / bids / buyouts
v1.2
Modifications for WoW 1.9 patch by Samah:
Samahlockeh (Orc Warlock) on Proudmoore
samahnub@gmail.com

Changes:
 - Support added for linked auction houses.
 - Added "Automatically Scan" option to disable scanning
   while in AH.
 - Clicking the TitanAuctions button will now perform a
   manual scan.

v1.1
-fixed nil probs at first startup
-minor cosmetic changes
-the expiry time will now still be visible if you have been outbid
-new option to show event time, which means the time outbid/sold/expired/etc.
-fixed problem where update from button wouldnt go away although tooltip was checked
v1.0
-first release