TITANEXITGAME_ARTWORK_PATH = "Interface\\AddOns\\TitanExitGame\\Artwork\\";

TITAN_EXITGAME_TOOLTIP = "Exit Game Menu";
TITAN_EXITGAME_TOOLTIP_HINT1 = "Left-click to open Logout or Exit Game Menu"
TITAN_EXITGAME_MENU_TEXT = "Exit Game";
LOG_OUT = "Logout";
EXIT_MENU = "Cancel";

-- German Translation by Whitehunter Big THANKS!!

if ( GetLocale() == "deDE" ) then
TITAN_EXITGAME_TOOLTIP = "Beenden Men\195\188";
TITAN_EXITGAME_TOOLTIP_HINT1 = "Links-Klick um das Beenden Men\195\188 zu \195\182ffnen"
TITAN_EXITGAME_MENU_TEXT = "Spiel verlassen";
LOG_OUT = "Ausloggen";
EXIT_MENU = "Zur\195\188ck zum Spiel";
end