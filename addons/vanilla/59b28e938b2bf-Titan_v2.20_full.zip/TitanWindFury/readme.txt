
	TitanWindFury 1.4 - created by Seaquest
	
	1.0 - Install Notes
	1.1 - Features
	1.2 - About
	1.3 - ChangeLog


	1.0 Install Notes --------------------------------------

	1. Extract TitanWindFury to you Interface/AddOns folder
	2. Ingame right click ur titan panel and select
	   Windfury

	3. If u upgrade from a previus version with 1.1 u may 
	   need to delete the weapon stats for it to fully work


	1.1 Features -------------------------------------------

	* Shows best single hit in a WF proc
	* Shows number of crits per WF for 5 last procs
	* Shows crit % for hits during WF proc
	* Shows last and best WindFury hit on TitanPanel
	* Track WindFury procs, average and total damage over 
	  lifetime and current session per weapon.


	1.2 About ----------------------------------------------

	Official site: http://bsitdesign.se/twf
	Author: Seaquest @ The Maelstrom (Euro)

	German launguage translator: Isnogud @ Gilneas (German)
	French launguage translator: Bloodix @ Illidan (French)

	Detect WF buff code: Flaw @ Cho'Gall (French)
	Fixes for 1.11: Rhidon @ Turalyon (Euro)

	
	1.3 TitanWindFury ChangeLog ----------------------------

	-- 2006-07-xx Version 1.4
		
		* [ADD]  Added support for SCT Output.
                * [FiX]  *waiting for beta testers.

	-- 2006-07-06 Version 1.3c (unofficial)
		
		* [FiX]  Fixed DPS Display to show again. (broke in 1.3b)
                * [FiX]  Fixed syntax errors in the translation files. (broke in 1.3b)

	-- 2006-07-06 Version 1.3b (unofficial)
		
		* [EDiT] Updated to 11100
		* [FiX]  Fixed WF tracking to work with WoW 1.11


	-- 04/04-2006 Version 1.3
		
		* [EDiT] Updated to 11000
		* [FiX]  Fixed WF tracking to work with new version!

		* Thanks to "Popo" for pointing out what was wrong

	-- 16/02-2005 Version 1.2
		
		* [FiX]  Fixed display bugg
		* [FiX]  French localization bugg

	-- 05/01-2005 Version 1.1
		
		* [ADD]  Shift + left-click on TWF button adds
		         WF stats to chat message (Unlocalized atm)
		* [FiX]  Tracking normal hits bugg
		* [EDiT] Changed the way WF buff is detected
		* [EDiT] Cleaned up stuff not needed anymore
		* [EDiT] Changed TOC number to 10900
	
	-- 28/12-2005 Version 1.0
		
		* [ADD]  Number of crits per WF for last 5 procs
		* [ADD]  French localization
		* [ADD]  Best single hit
		* [ADD]  Proc rate in %

		* [EDiT] Data is now saved per weapon
		* [EDiT] Rewrote almost all code

		* previus version numbers skipped due to beta testing

	-- 23/11-2005 Version 0.7

		* [ADD]  Added 5 last WF hits
		* [FiX]  Fixxed the way it saves data over sessions
		* [FiX]  Localization error

	-- 22/11-2005 Version 0.6

		* [ADD]  Crit % for hits during WF proc
		* [ADD]  Launguage support for German
		
		* [FiX]  Fixed some errors caused by nil values

		* [EDiT] Changed the way it saves data over sessions

		* previus version numbers skipped due to beta testing
	
	-- 10/11-2005 Version 0.1

		* First Release