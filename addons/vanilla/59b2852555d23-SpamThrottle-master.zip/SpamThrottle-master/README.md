# SpamThrottle - version 1.12

Vanilla WoW addon to remove unwanted chat messages.

To install, click the "Download ZIP" button on the right hand side (above), which will download the SpamThrottle-master.zip file. Inside that ZIP archive there is a folder called SpamThrottle. Copy that folder into the Interface/Addons directory under your main WoW installation.
