if ( GetLocale() == "deDE" ) then
	-- Credits to Hj�rvar�r for these

	GMAIL_HELP = "Belege soviele Pl\195\164tze wie du m\195\182chtest. Jeder Gegenstand wird seperat an den Empf\195\164nger gesendet, und zwar mit dem Betreff den du bestimmst gefolgt vom Namen des Gegenstands und dessen Anzahl (z.B. <Betreff> [Goldbarren x10]). Die zusammengefassten Versandkosten werden oben rechts angezeigt. Du kannst Gegenst\195\164nde in deinen Taschen durch Alt-Klick automatisch zur Liste hinzuf\195\188gen.";

	GMAIL_SEND = "Post verschicken";
	GMAIL_SENDBUTTON = "Verschicken";
	GMAIL_CANCELBUTTON = "Abbrechen";

	GMAIL_SENDINFO = "Bist du sicher das du die Post verschicken willst?  Die gesamten Versandkosten belaufen sich auf:";
	GMAIL_SENDINFO2 = "Du verschickst:";
	GMAIL_ITEMS = "Item(s)";
	GMAIL_ABORT = "Abbrechen";

	GMAIL_ITEMNUM = "Gegenstand %d von %d.";
	GMAIL_SENDING = "Verschicke P\195\164ckchen |c00FFFFFF%d|r/|c00FFFFFF%d|r...";
	GMAIL_DONESENDING = "Verschicken von |c00FFFFFF%d|r P\195\164ckchen erledigt!";
	GMAIL_ABORTED = "Abgebrochen. |c00FFFFFF%d|r/|c00FFFFFF%d|r P\195\164ckchen wurde(n) verschickt.";
	GMAIL_ERROR = "Ein Fehler in GMail ist aufgetreten. Bitte \195\188bermittle einen Fehlerbericht auf http://www.ctmod.net";
end
