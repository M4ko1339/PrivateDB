AFDeltaTime = 0
AFTick = 0
AFBuffs = {}
IsMounted = false;

function AFRound(int)
	return math.floor(int+0.5)
end


function AFSendMessage(msg,ChannelName)
	id1, name1, id2, name2, id3, name3, id4,name4, id5,name5, id6,name6, id7,name7, id8,name8, id9,name9, id10,name10  =  GetChannelList()
	channels = {name1,name2,name3,name4,name5,name6,name7,name8,name9,name10}
	channelsID = {id1,id2,id3,id4,id5,id6,id7,id8,id9,id10}
	for index = 1, table.getn(channels) do
		if (channels[index] == ChannelName) then
			SendChatMessage(msg,"CHANNEL",nil,channelsID[index]);
		end
	end
end


function AFAddNewLines(msg,String)
	local nameFragments = {};
	for word in string.gfind(msg, "[^%s]+") do
		table.insert(nameFragments, word);
	end
	
	local FullName = ""
	for index = 1,table.getn(nameFragments) do
		if (nameFragments[index] == String) then
			nameFragments[index] = "\r"
		else
			nameFragments[index] = nameFragments[index].." "
		end
		if FullName == "" then
			FullName = nameFragments[index];
		else
			FullName = (FullName..(nameFragments[index]));
		end
	end
	return FullName;
end


function AFDeparse(nameFragments, start)
	local FullName = ""
	for index = start,table.getn(nameFragments) do
		if FullName == "" then
			FullName = nameFragments[index];
		else
			FullName = (FullName.." "..(nameFragments[index]));
		end
	end
	return FullName;
end



function AFSpaceToScore(msg)
	local nameFragments = {};
	for word in string.gfind(msg, "[^%s]+") do
		table.insert(nameFragments, word);
	end
	
	local FullName = ""
	for index = 1,table.getn(nameFragments) do
		if FullName == "" then
			FullName = nameFragments[index];
		else
			FullName = (FullName.."_"..(nameFragments[index]));
		end
	end
	return FullName;
end



function AFToMoney(input)
	local Gold = math.floor(input/10000);
	local Silver = math.floor((input - Gold*10000)/100);
	local Bronze = input - Gold * 10000 - Silver * 100;
	local String = 0;
	if Gold > 0 then
		String = Gold.."g";
	end
	if Silver > 0 then
		if Gold > 0 then
			String = String..", "..Silver.."s";
		else
			String = Silver.."s";
		end
	end
	if Bronze > 0 then
		if Gold > 0 or Silver > 0 then
			String = String..", "..Bronze.."c";
		else
			String = Bronze.."c";
		end
	end
	return String;
end


function GetItemSelectedInfo(Link,itemType)
	local a,b,c,d,e,f,g,h = GetItemInfo(GetItemLink(Link));
	local info = {}
	info["NAME"] = a;
	info["LINK"] = b;
	info["COLOR"] = c;
	info["LEVEL"] = d;
	info["TYPE"] = e;
	info["SUBTYPE"] = f;
	info["MAXSTACK"] = g
	return info[itemType];
end

function GetItemType(Link)
	local a,b,c,d,e,f,g,h = GetItemInfo(GetItemLink(Link));
	--a = name, b = link, c = color, d = level, e = AHtype, f = subtype, g = max stack
	return e;
end
function GetItemName(Link)
	itemLink=GetItemLink(Link)
	local name = GetItemInfo(itemLink);
	return name;
end
function GetItemColor(Link)
	itemLink=GetItemLink(Link)
	local _,_,color = GetItemInfo(itemLink);
	return color;
end
function GetItemLink(Link)
	local _,_,itemLink=string.find(Link,"(item:%d+)");
	return itemLink;
end

function AFCastError(Caller,String)
	DEFAULT_CHAT_FRAME:AddMessage("["..Caller.." Error]: "..String, 0.8, 0.0, 0.0);
end
function AFPrintNote(Caller,String)
	DEFAULT_CHAT_FRAME:AddMessage("["..Caller.."]: "..String, 1.0, 1.0, 0.0);
end
function Print(String)
	DEFAULT_CHAT_FRAME:AddMessage(String, 1.0, 1.0, 0.0);
end
function ChatPrint(msg)
	msg = AFAddNewLines(msg,"\\r")
	DEFAULT_CHAT_FRAME:AddMessage(msg, 0.4, 1, 1);
end
function AFGetBuffs()
	local i = 1;
	local buff = UnitBuff("player", i);
	local buffs = {buff};
	while buff do
  		i = i + 1;
  		buff = UnitBuff("player", i);
  		buffs[table.getn(buffs) + 1] = buff;
  	end;
  	return buffs;
end

function AFSearchForBuff(buff)
	AFBuffs = AFGetBuffs();
	local Found = false;
	for i = 1, table.getn(AFBuffs) do
		if (AFBuffs[i] == buff)  then
			Found = true;		
		end
	end
	return Found;
end


-- On Update
function ArynasFunctions_OnUpdate()
	AFTimer = GetTime();
	if (AFTimer - AFDeltaTime >= 0.1) then
		AFDeltaTime = AFTimer;
		AFTick = AFTick+1;
		AFBuffs = AFGetBuffs();
		IsMounted = AFSearchForBuff("Interface\\Icons\\Ability_Mount_Dreadsteed");
	end
end


-- Enter Combat Frame
CreateFrame("Frame", "ArynasFunctions_EnterCombat");
ArynasFunctions_EnterCombat:SetScript("OnEvent", function()
	InCombat = true;
end);
ArynasFunctions_EnterCombat:RegisterEvent("PLAYER_ENTER_COMBAT");


-- Leave Combat
CreateFrame("Frame", "ArynasFunctions_LeaveCombat");
ArynasFunctions_LeaveCombat:SetScript("OnEvent", function()
	InCombat = false;
	--Print("You left the fight");
end);
ArynasFunctions_LeaveCombat:RegisterEvent("PLAYER_LEAVE_COMBAT");


CreateFrame("Frame", "ArynasFunctions_AddonUpdate");
ArynasFunctions_AddonUpdate:SetScript("OnUpdate", function()
	ArynasFunctions_OnUpdate()
end);