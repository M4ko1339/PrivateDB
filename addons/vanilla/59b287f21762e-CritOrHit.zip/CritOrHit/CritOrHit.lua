function GetCritValue(sp, crit)
	return ((1.0 + (( crit / 100 ) + ( 1.0 / 100 )) + (( crit / 100 ) + ( 1.0 / 100 )) * ((0.2 * 4) - (0.2 * 2 * (( crit / 100 ) + ( 1.0 / 100 ))) - (0.2 * (1-(( crit / 100 ) + ( 1.0 / 100 )))* (( crit / 100 ) + ( 1.0 / 100 ))) + 0.2 * (( crit / 100 ) + ( 1.0 / 100 )) * math.pow(( 1.0 - (( crit / 100 ) + ( 1.0 / 100 )) ),3)))/(1.0 + ( crit / 100 ) + ( crit / 100 ) * ((0.2 * 4) - (0.2 * 2 * ( crit / 100 )) - (0.2 * (1-( crit / 100 ))* ( crit / 100 )) + 0.2 * ( crit / 100 ) * math.pow(( 1.0 - ( crit / 100 ) ),3))) - 1) * 100 / (85.71 / (510 + sp * 0.8571))
end

function GetHitValue(sp, hit)
	return 100 / (83 + hit) / (85.71 / (510 + sp * 0.8571))
end

function CritVsHit(crit, hit)
	local cycles = 1000000
	local debuff = 0
	local dmg = 0
	local hitchance = (83 + hit)/100
	local critchance = crit/100
	local xdmg = 1;
	local crits = 0
	local hits = 0
	for timer = 1, cycles do
		if (hitchance > math.random()) then
			hits = hits+1
			xdmg = 1
			if (debuff > 0) then
				xdmg = xdmg * 1.2
			end
			if (critchance > math.random()) then
				crits = crits + 1
				xdmg = xdmg * 2
				debuff = 5
			end
			debuff = debuff - 1
			dmg = dmg + xdmg
		end		
	end
	return "Avg DMG: "..(AFRound(dmg*10000/cycles)/10000)..". Crits: "..(AFRound(crits/cycles*1000)/10).."%. Hits: "..(AFRound(hits/cycles*1000)/10).."%."
end

-- Slash commands
SLASH_COHCOMMANDS1 = "/coh";


SlashCmdList["COHCOMMANDS"] = function(Flag)
	flag = string.lower(Flag);
	words = {};
	for word in string.gfind(flag, "[^%s]+") do
		table.insert(words, word);
	end
	Words = {};
	for word in string.gfind(Flag, "[^%s]+") do
		table.insert(Words, word);
	end
	if (words[1]) then
		cmd = words[1];
		local sp = BonusScanner:GetBonus("DMG") + BonusScanner:GetBonus("SHADOWDMG");
		local _, int = UnitStat("player", 4);
		local crit = BonusScanner:GetBonus("SPELLCRIT") + int/60.6 + 5 + 1.7
		local hit = BonusScanner:GetBonus("SPELLTOHIT")
		if (cmd == "critvshit") or (cmd == "cvh") then
			Print("Current Gear: "..CritVsHit(crit,hit))
			Print("1 more crit: "..CritVsHit(crit+1,hit))
			Print("1 mor hit: "..CritVsHit(crit,hit+1))
			
		elseif (cmd == "sp") then
			Print("You have "..sp.." spell power.");
		elseif (cmd == "crit") then
			Print("One crit is worth "..(math.floor(GetCritValue(sp,crit)*10)/10).." spell power.");
		elseif (cmd == "hit") then
			Print("One hit is worth "..(math.floor(GetHitValue(sp,hit)*10)/10).." spell power.");
		else
			Print("[CritOrHit]: Unknown command.");
		end
	else
		Print("/coh crit for crit info.");
		Print("/coh hit for hit info.");
	end
end



function COHOnLoad()
	--function defined =D
end


CreateFrame("Frame", "COHMain");
COHMain:SetScript("OnEvent", function()
	if arg1 == "CritOrHit" then
		COHMain:UnregisterEvent("ADDON_LOADED");
		COHOnLoad();
	end
end);
COHMain:RegisterEvent("ADDON_LOADED");