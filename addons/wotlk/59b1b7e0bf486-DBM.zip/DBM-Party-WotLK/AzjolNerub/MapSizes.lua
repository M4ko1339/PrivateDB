DBM:RegisterMapSize("AzjolNerub",
	1, 752.973999023, 501.983001709,	-- The Brood Pit
	2, 292.973999023, 195.31597900,		-- Hadronox's Lair
	3, 367.5, 245						-- The Gilded Gate
)
