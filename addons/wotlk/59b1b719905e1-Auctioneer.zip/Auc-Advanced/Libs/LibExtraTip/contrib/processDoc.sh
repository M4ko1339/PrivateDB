#!/bin/ksh

perl processDoc.pl ../LibExtraTip.lua
mv API.html ../API.html

